import React from 'react';
import ReactDom from 'react-dom';
import SampleComponent from './sample-component.js';

ReactDom.render(
  <SampleComponent />,
  document.getElementById('container')
);
