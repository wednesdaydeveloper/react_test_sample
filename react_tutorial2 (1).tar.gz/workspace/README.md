ここを参考にしました。

http://qiita.com/nownabe/items/2d8b92d95186c3941de0

ここを参考にテスト

http://qiita.com/teppei_tosa/items/46087a35776e14c89d42